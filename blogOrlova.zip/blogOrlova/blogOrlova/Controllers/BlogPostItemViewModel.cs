﻿namespace blogOrlova.Controllers
{
    internal class BlogPostItemViewModel
    {
        public object Author { get; set; }
        public object Created { get; set; }
        public object Data { get; set; }
        public object Title { get; set; }
    }
}