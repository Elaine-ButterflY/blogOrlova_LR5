﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace blogOrlova.Migrations
{
    public partial class add_blogPosts : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
